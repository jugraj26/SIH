CONNECTED VERSION

Frontend: price-dashboard
Backend: price-predictor-prototype

Frontend calls /api/predict/{commodity}; Vite proxies /api to http://127.0.0.1:8000.
Backend has CORS enabled and a demo generate_mock_data() implementation so the existing XGBoost endpoint can run.

Run backend:
  cd price-predictor-prototype
  python -m uvicorn main:app --reload

Run frontend in a second terminal:
  cd price-dashboard
  npm.cmd run dev

Then open the Vite URL and go to Price Forecast -> Predict Price.
