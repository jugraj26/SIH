from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List
import pandas as pd
from pymongo import MongoClient

from src.data_loader import generate_mock_data, build_features
from src.model import train_and_predict
from src.logic import evaluate_decision_support

app = FastAPI(
    title="Price Predictor Intelligence API",
    description="Backend API for predicting prices and evaluating strategic buffer actions.",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:5174"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize MongoDB Client (Default local connection)
# Initialize MongoDB Client (MongoDB Atlas Cloud connection)
MONGO_URI = "mongodb+srv://ojasbhavsar007_db_user:sECLqQqzykjqTKtd@cluster0.loeyevl.mongodb.net/?appName=Cluster0"
mongo_client = MongoClient(MONGO_URI)
db = mongo_client["price_tracker_db"]
logs_collection = db["price_logs"]

class FactorImportance(BaseModel):
    factor: str
    importance: float

class PredictionResponse(BaseModel):
    commodity: str
    current_price: float
    predicted_price: float
    pct_change: float
    risk_level: str
    action: str
    factors: List[FactorImportance]

@app.get("/")
def read_root():
    return {"status": "online", "message": "Price Intelligence API is running with MongoDB."}

@app.get("/predict/{commodity}", response_model=PredictionResponse)
def predict_commodity_price(commodity: str):
    try:
        # 1. Fetch data & build features
        raw_df = generate_mock_data(commodity=commodity, days=365)
        featured_df = build_features(raw_df)

        # 2. Run model inference
        current_price, predicted_price, factors = train_and_predict(featured_df)

        # 3. Evaluate decision logic
        pct_change, risk_level, action = evaluate_decision_support(current_price, predicted_price)

        # 4. Save record to MongoDB collection
        log_document = {
            "commodity": commodity,
            "current_price": current_price,
            "predicted_price": predicted_price,
            "pct_change": pct_change,
            "risk_level": risk_level,
            "action": action
        }
        logs_collection.insert_one(log_document)

        return PredictionResponse(
            commodity=commodity,
            current_price=current_price,
            predicted_price=predicted_price,
            pct_change=pct_change,
            risk_level=risk_level,
            action=action,
            factors=factors
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))