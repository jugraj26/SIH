import pandas as pd
import requests
import os

def generate_mock_data(commodity: str = "Onion", days: int = 365) -> pd.DataFrame:
    """Generate demo price/arrival history when a real mandi dataset is not connected yet."""
    import numpy as np

    np.random.seed(abs(hash(commodity)) % (2**32))
    base_prices = {
        "Onion": 3000,
        "Tomato": 2500,
        "Wheat": 2800,
        "Rice (Paddy)": 3500,
        "Potato": 2200,
        "Tur Dal (Arhar)": 7500,
        "Soybean": 4800,
        "Sugarcane": 3500,
    }
    base = base_prices.get(commodity, 3000)

    prices = []
    arrivals = []
    price = float(base)
    for _ in range(days):
        price = max(base * 0.5, price + np.random.normal(0, base * 0.02))
        prices.append(round(price, 2))
        arrivals.append(round(np.random.uniform(200, 1000), 2))

    df = pd.DataFrame({"modal_price": prices, "arrivals_qtl": arrivals})
    df["price_lag_1"] = df["modal_price"].shift(1)
    df["price_lag_7"] = df["modal_price"].shift(7)
    df["price_lag_14"] = df["modal_price"].shift(14)
    df["rolling_mean_7"] = df["modal_price"].rolling(7).mean()
    df["rolling_std_7"] = df["modal_price"].rolling(7).std()
    return df.dropna().reset_index(drop=True)

def load_excel_data(file_path: str) -> pd.DataFrame:
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File not found at: {file_path}")

    # FIX: Use read_csv instead of read_excel
    df = pd.read_csv(file_path)
    df.columns = df.columns.str.strip()
    return df

def fetch_weather_data(lat: float = 19.0760, lon: float = 72.8777) -> dict:
    url = f"https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lon}&daily=temperature_2m_max,rain_sum&timezone=auto"
    try:
        response = requests.get(url, timeout=5)
        if response.status_code == 200:
            data = response.json()
            daily = data.get("daily", {})
            max_temp = daily.get("temperature_2m_max", [28.0])[0]
            rainfall = daily.get("rain_sum", [0.0])[0]
            return {"max_temp_c": max_temp, "rainfall_mm": rainfall}
    except Exception as e:
        print(f"Weather API fallback used due to: {e}")
    
    return {"max_temp_c": 28.0, "rainfall_mm": 0.0}

def build_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.fillna(0)
    weather = fetch_weather_data()
    df["max_temp_c"] = weather["max_temp_c"]
    df["rainfall_mm"] = weather["rainfall_mm"]
    return df